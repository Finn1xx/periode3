<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Chirpify - Login </title>
    <link rel="stylesheet" href="create_account.css">
</head>

<body>

    <main>
        <div class="contact-box">
            <form class="form-box" action="login.php" method="POST">
                <H1>Login.</H1>
                <input type="email" class="input-field" placeholder="Email" name="email" required>
                <input type="password" class="input-field" placeholder="Password" name="password" required>
                <input type="submit" class="button-styling-login" value="Login Chirpify">
            </form> 
        </div>
    </main>

</body>
</html>